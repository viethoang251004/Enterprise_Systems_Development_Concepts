# Sai Cafe
Online Food Ordering System Project

## Project Status
- Status: COMPLETED
- Completion: **100%**

## Project Description
FoodShop: An Online Food Ordering and Management System
FoodShop is an innovative web-based application designed to streamline the process of food ordering and management for stores within a unified system. The system is particularly tailored to cater to canteens, cafeterias, and food courts in diverse institutions such as educational campuses, IT sectors, and factories. These establishments often face challenges like overcrowding during peak hours, resulting in long queues for billing and food delivery, increased waiting times, and potential human errors in accounting and order handling.

## Software Tools Used in this Project
- HTML 5
- CSS 3
- JavaScript
- PHP 8.0.9
- MySQL Database
- Bootstrap 5.1.3
- Omise API Version 2019-05-29

## Note
- To use Omise API in PHP language for your project, go to https://github.com/omise/omise-php. For more information about Omise Payment API, visit https://www.omise.co/docs
- Food images included in the img folder.
- To install the FoodShop web app, download and install XAMPP, download this repository and put into directory (C:/xampp/htdocs/), import database and name it food_management in phpMyAdmin (http://localhost/phpmyadmin) using file Saicafe.sql, start Apache and MySQL services, then run and access by using web browser (http://localhost/saicafe/) and enjoy.
- You can register for the customer account and log in. To log in with shop account, press the log in with shop account under login page. Add shop account using the admin mode. Access admin mode by clicking at the "log in to your admin account" in the footer at the customer log in page. You can look up 

## Members
- 521H0461

Card number: (Test card number by omise library)
Visa
4242 4242 4242 4242
Mastercard
5555 5555 5555 4444
JCB
3530 1113 3330 0000
3566 1111 1111 1113
American Express (AMEX)
3782 822463 10005
Diners Club
3624 2423 2320 03
Discover
6011 1111 1111 1117
UnionPay
6200 0000 0000 0005

