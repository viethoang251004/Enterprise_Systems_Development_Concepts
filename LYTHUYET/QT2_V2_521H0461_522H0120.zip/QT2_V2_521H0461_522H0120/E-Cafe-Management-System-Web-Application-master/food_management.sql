-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2024 at 05:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food_management`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `customer_order` (IN `order_id` INT(11))   BEGIN
	SELECT orh.orh_refcode AS reference_code, CONCAT(c.c_firstname,' ',c.c_lastname) AS customer_name, s.s_name AS shop_name,f.f_name AS food_name,ord.ord_buyprice AS buy_price, ord.ord_amount AS amount ,ord.ord_note AS order_note, orh.orh_ordertime AS order_time , orh.orh_pickuptime AS pickup_time
    FROM order_header orh 
    INNER JOIN order_detail ord ON orh.orh_id = ord.orh_id
    INNER JOIN food f ON f.f_id = ord.f_id
    INNER JOIN customer c ON orh.c_id = c.c_id
    INNER JOIN shop s ON orh.s_id = s.s_id
    WHERE orh.orh_id = order_id; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `customer_order_history` (IN `customer_id` INT(11))   BEGIN
	SELECT orh.orh_refcode AS reference_code, CONCAT(c.c_firstname,' ',c.c_lastname) AS customer_name,
    s.s_name AS shop_name, orh.orh_ordertime AS order_time, orh.orh_pickuptime AS pickup_time,
    p.p_amount AS order_cost, orh.orh_orderstatus AS order_status
    FROM order_header orh INNER JOIN customer c ON orh.c_id = c.c_id
    INNER JOIN payment p ON orh.p_id = p.p_id
    INNER JOIN shop s ON orh.s_id = s.s_id
    WHERE c.c_id = customer_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `shop_alltime_revenue` (IN `shop_id` INT(11))   BEGIN
	SELECT SUM(ord.ord_amount*ord.ord_buyprice) AS alltime_revenue 
    FROM order_header orh INNER JOIN order_detail ord ON orh.orh_id = ord.orh_id
    INNER JOIN food f ON f.f_id = ord.f_id INNER JOIN shop s ON s.s_id = orh.s_id
    WHERE s.s_id = shop_id AND orh.orh_orderstatus = 'FNSH';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `shop_menu_revenue` (IN `shop_id` INT(11))   BEGIN
	SELECT f.f_name AS food_name, SUM(ord.ord_amount*ord.ord_buyprice) AS menu_revenue
    FROM order_header orh INNER JOIN order_detail ord ON orh.orh_id = ord.orh_id
    INNER JOIN food f ON f.f_id = ord.f_id
    WHERE orh.s_id = shop_id AND orh.orh_orderstatus = 'FNSH'
    GROUP BY ord.f_id ORDER BY menu_revenue DESC;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `ct_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `f_id` int(11) NOT NULL,
  `ct_amount` int(11) NOT NULL,
  `ct_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_id` int(11) NOT NULL,
  `c_username` varchar(45) NOT NULL,
  `c_pwd` varchar(45) NOT NULL,
  `c_firstname` varchar(45) NOT NULL,
  `c_lastname` varchar(45) NOT NULL,
  `c_email` varchar(100) NOT NULL,
  `c_gender` varchar(1) NOT NULL COMMENT 'M for Male, F for Female',
  `c_type` varchar(3) NOT NULL COMMENT 'Type of customer in this canteen (STD for student, INS for instructor, STF for staff, GUE for guest, ADM for admin, OTH for other)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_id`, `c_username`, `c_pwd`, `c_firstname`, `c_lastname`, `c_email`, `c_gender`, `c_type`) VALUES
(2, 'cust1', '11111111', 'Customer 1', 'Customer 1', 'customer1@gmail.com', 'F', 'STD'),
(3, 'cust2', '11111111', 'Customer 2', 'Customer 2', 'customer2@gmail.com', 'M', 'INS'),
(4, 'admin', '12345678', 'Admin', 'Admin', 'admin@gmail.com', 'M', 'ADM'),
(5, '521H0461', '12345678', 'Tran', 'Kiet', 'kiet@gmail.com', 'M', 'STD');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `f_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `f_price` decimal(6,2) NOT NULL,
  `f_todayavail` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'Food is available to order or not',
  `f_preorderavail` tinyint(4) NOT NULL DEFAULT 1,
  `f_pic` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`f_id`, `s_id`, `f_name`, `f_price`, `f_todayavail`, `f_preorderavail`, `f_pic`) VALUES
(8, 1, 'Cà phê', 25.00, 1, 1, '8_1.jpg'),
(9, 1, 'Bún bò', 40.00, 1, 1, '9_1.jpg'),
(10, 1, 'Cơm gà xối mỡ', 40.00, 1, 1, '10_1.jpg'),
(11, 1, 'Phở bò', 40.00, 1, 1, '11_1.avif'),
(12, 1, 'Bánh cuốn', 25.00, 1, 1, '12_1.jpg'),
(13, 1, 'Nước mía', 15.00, 1, 1, '13_1.jpg'),
(14, 1, 'Trà đá', 5.00, 1, 1, '14_1.jpg'),
(15, 1, 'Sinh tố dâu', 25.00, 1, 1, '15_1.jpg'),
(16, 1, 'Bánh mì', 20.00, 1, 1, '16_1.avif'),
(17, 2, 'Kimchi', 5.00, 1, 1, '17_2.jpg'),
(18, 2, 'Bimbimbap', 35.00, 1, 1, '18_2.jpg'),
(19, 2, 'Bulgogi', 45.00, 1, 1, '19_2.jpg'),
(20, 2, 'Hobakjuk', 25.00, 1, 1, '20_2.jpg'),
(21, 2, 'Tokbokki', 30.00, 1, 1, '21_2.jpg'),
(22, 2, 'Gimbap', 40.00, 1, 1, '22_2.jpg'),
(23, 2, 'Tteok', 15.00, 1, 1, '23_2.jpg'),
(24, 3, 'Miso soup', 30.00, 1, 1, '24_3.jpg'),
(25, 3, 'Takoyaki', 25.00, 1, 1, '25_3.jpg'),
(26, 3, 'Ramen', 40.00, 1, 1, '26_3.jpg'),
(27, 3, 'Sushi', 50.00, 1, 1, '27_3.jpg'),
(28, 3, 'Tempura', 25.00, 1, 1, '28_3.jpg'),
(29, 3, 'Onigiri', 20.00, 1, 1, '29_3.jpg'),
(30, 5, 'Gà rán truyền thống', 25.00, 1, 1, '30_5.png'),
(31, 5, 'Gà rán sốt cay', 30.00, 1, 1, '31_5.jpg'),
(32, 5, 'Khoai tây chiên', 30.00, 1, 1, '32_5.png'),
(33, 5, 'Hamburger gà', 40.00, 1, 1, '33_5.png'),
(34, 5, 'Combo 1', 70.00, 1, 1, '34_5.png'),
(35, 5, 'Combo 2', 75.00, 1, 1, '35_5.png'),
(36, 5, 'Combo 3', 75.00, 1, 1, '36_5.png'),
(37, 6, 'Khao soi', 35.00, 1, 1, '37_6.jpg'),
(38, 6, 'Mango Sticky Rice', 30.00, 1, 1, '38_6.jpg'),
(39, 6, 'Pad Thai', 40.00, 1, 1, '39_6.jpg'),
(40, 6, 'Tom Yum', 35.00, 1, 1, '40_6.jpg'),
(41, 6, 'Green Cury', 30.00, 1, 1, '41_6.jpg'),
(42, 6, 'Red Curry', 30.00, 1, 1, '42_6.jpg'),
(43, 6, 'Stir Fried Rice', 45.00, 1, 1, '43_6.jpg'),
(44, 8, 'Roast Duck', 50.00, 1, 1, '44_8.jpg'),
(45, 8, 'Hot Pot', 75.00, 1, 1, '45_8.jpg'),
(46, 8, 'Wonton', 25.00, 1, 1, '46_8.jpg'),
(47, 8, 'Mooncake', 30.00, 1, 1, '47_8.jpg'),
(48, 8, 'Glutinous Rice all', 25.00, 1, 1, '48_8.jpg'),
(49, 8, 'Tomatoes On Stick', 20.00, 1, 1, '49_8.jpg'),
(50, 8, 'Dongo Pork', 40.00, 1, 1, '50_8.jpg'),
(51, 8, 'Lousifen', 35.00, 1, 1, '51_8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `ord_id` int(11) NOT NULL,
  `orh_id` int(11) NOT NULL,
  `f_id` int(11) NOT NULL,
  `ord_amount` int(11) NOT NULL,
  `ord_buyprice` decimal(6,2) NOT NULL COMMENT 'To keep the snapshot of selected menu cost at the time of the purchase.',
  `ord_note` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`ord_id`, `orh_id`, `f_id`, `ord_amount`, `ord_buyprice`, `ord_note`) VALUES
(1, 1, 8, 1, 25.00, ''),
(2, 1, 16, 1, 20.00, ''),
(3, 1, 10, 1, 40.00, ''),
(4, 1, 9, 1, 40.00, ''),
(5, 1, 14, 4, 5.00, ''),
(6, 2, 17, 1, 5.00, ''),
(7, 2, 18, 1, 35.00, ''),
(8, 2, 20, 2, 25.00, ''),
(9, 3, 24, 1, 30.00, ''),
(10, 3, 27, 1, 50.00, ''),
(11, 3, 29, 2, 20.00, ''),
(12, 3, 28, 1, 25.00, ''),
(13, 4, 30, 2, 25.00, ''),
(14, 4, 32, 2, 30.00, ''),
(15, 4, 33, 1, 40.00, ''),
(16, 5, 38, 3, 30.00, ''),
(17, 5, 40, 1, 35.00, ''),
(18, 5, 39, 1, 40.00, ''),
(19, 5, 43, 1, 45.00, ''),
(20, 6, 44, 1, 50.00, ''),
(21, 6, 47, 4, 30.00, ''),
(22, 6, 49, 2, 20.00, 'not spicy'),
(23, 6, 45, 1, 75.00, 'more chilli');

-- --------------------------------------------------------

--
-- Table structure for table `order_header`
--

CREATE TABLE `order_header` (
  `orh_id` int(11) NOT NULL,
  `orh_refcode` varchar(15) DEFAULT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `orh_ordertime` timestamp NOT NULL DEFAULT current_timestamp(),
  `orh_pickuptime` datetime NOT NULL,
  `orh_orderstatus` varchar(10) NOT NULL,
  `orh_finishedtime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_header`
--

INSERT INTO `order_header` (`orh_id`, `orh_refcode`, `c_id`, `s_id`, `p_id`, `orh_ordertime`, `orh_pickuptime`, `orh_orderstatus`, `orh_finishedtime`) VALUES
(1, '202411160000001', 5, 1, 1, '2024-11-16 04:35:03', '2024-11-16 11:34:00', 'FNSH', '2024-11-16 11:43:10'),
(2, '202411160000002', 2, 2, 2, '2024-11-16 04:36:42', '2024-11-16 11:36:00', 'FNSH', '2024-11-16 11:43:05'),
(3, '202411160000003', 3, 3, 3, '2024-11-16 04:38:16', '2024-11-16 11:37:00', 'RDPK', '0000-00-00 00:00:00'),
(4, '202411160000004', 5, 5, 4, '2024-11-16 04:46:01', '2024-11-16 11:45:00', 'ACPT', NULL),
(5, '202411160000005', 5, 6, 5, '2024-11-16 04:46:31', '2024-11-16 11:46:00', 'FNSH', '2024-11-16 11:48:26'),
(6, '202411160000006', 5, 8, 6, '2024-11-16 04:47:56', '2024-11-16 11:47:00', 'PREP', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `p_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `p_type` varchar(45) NOT NULL,
  `p_amount` decimal(7,2) NOT NULL,
  `p_detail` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`p_id`, `c_id`, `p_type`, `p_amount`, `p_detail`) VALUES
(1, 5, 'CRDC', 145.00, 'Visa [*4242]'),
(2, 2, 'CRDC', 90.00, 'Visa [*4242]'),
(3, 3, 'CRDC', 145.00, 'Visa [*4242]'),
(4, 5, 'CRDC', 150.00, 'Visa [*4242]'),
(5, 5, 'CRDC', 210.00, 'Visa [*4242]'),
(6, 5, 'CRDC', 285.00, 'Visa [*4242]');

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `s_id` int(11) NOT NULL,
  `s_username` varchar(45) NOT NULL,
  `s_pwd` varchar(45) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `s_location` varchar(100) NOT NULL,
  `s_openhour` time NOT NULL,
  `s_closehour` time NOT NULL,
  `s_status` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'Shop ready for taking an order or not (True for open, False for close)',
  `s_preorderStatus` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'Shop is ready for tomorrow pre-order or not',
  `s_email` varchar(100) NOT NULL,
  `s_phoneno` varchar(45) NOT NULL,
  `s_pic` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`s_id`, `s_username`, `s_pwd`, `s_name`, `s_location`, `s_openhour`, `s_closehour`, `s_status`, `s_preorderStatus`, `s_email`, `s_phoneno`, `s_pic`) VALUES
(1, 'Shop 1', '12345678', 'Vietnamese Restaurant', 'Unit #1', '07:30:00', '19:30:00', 1, 1, 'Shop1@gmail.com', '0900001234', 'shop1.jpg'),
(2, 'Shop 2', '12345678', 'Korean Restaurant', 'Unit #2', '08:00:00', '17:30:00', 1, 1, 'Shop2@gmail.com', '0900000002', 'shop2.jpg'),
(3, 'Shop 3', '12345678', 'Japanese Restaurant', 'Unit #3', '08:30:00', '22:00:00', 1, 1, 'Shop3@gmail.com', '0901234567', 'shop3.jpg'),
(5, 'Shop 4', '12345678', 'FastFood Restaurant', 'Unit #4', '07:00:00', '22:00:00', 1, 1, 'Shop4@gmail.com', '0123456567', 'shop5.jpg'),
(6, 'Shop 5', '12345678', 'Siamese Restaurant', 'Unit #5', '05:35:00', '19:30:00', 1, 1, 'Shop5@gmail.com', '09221111111', 'shop6.jpg'),
(8, 'Shop 6', '12345678', 'Chinese Restaurant', 'Unit #6', '06:00:00', '21:00:00', 1, 1, 'Shop6@gmail.com', '021666626', 'shop8.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`ct_id`),
  ADD KEY `fk_ct_c_idx` (`c_id`),
  ADD KEY `fk_ct_s_idx` (`s_id`),
  ADD KEY `fk_ct_f_idx` (`f_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_id`),
  ADD UNIQUE KEY `c_username` (`c_username`),
  ADD UNIQUE KEY `c_email` (`c_email`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`f_id`),
  ADD KEY `food_shop_s_id_idx` (`s_id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`ord_id`),
  ADD KEY `fk_orh_ord_idx` (`orh_id`),
  ADD KEY `fk_f_ord_idx` (`f_id`);

--
-- Indexes for table `order_header`
--
ALTER TABLE `order_header`
  ADD PRIMARY KEY (`orh_id`),
  ADD KEY `fk_orh_idx` (`c_id`),
  ADD KEY `fk_s_orh_idx` (`s_id`),
  ADD KEY `fk_p_orh_idx` (`p_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `p_c_fk_idx` (`c_id`);

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`s_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `ct_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `ord_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `order_header`
--
ALTER TABLE `order_header`
  MODIFY `orh_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `shop`
--
ALTER TABLE `shop`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_ct_c` FOREIGN KEY (`c_id`) REFERENCES `customer` (`c_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ct_f` FOREIGN KEY (`f_id`) REFERENCES `food` (`f_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ct_s` FOREIGN KEY (`s_id`) REFERENCES `shop` (`s_id`) ON DELETE CASCADE;

--
-- Constraints for table `food`
--
ALTER TABLE `food`
  ADD CONSTRAINT `fk_food_shop_id` FOREIGN KEY (`s_id`) REFERENCES `shop` (`s_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD CONSTRAINT `fk_f_ord` FOREIGN KEY (`f_id`) REFERENCES `food` (`f_id`),
  ADD CONSTRAINT `fk_orh_ord` FOREIGN KEY (`orh_id`) REFERENCES `order_header` (`orh_id`) ON DELETE CASCADE;

--
-- Constraints for table `order_header`
--
ALTER TABLE `order_header`
  ADD CONSTRAINT `fk_c_orh` FOREIGN KEY (`c_id`) REFERENCES `customer` (`c_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_p_orh` FOREIGN KEY (`p_id`) REFERENCES `payment` (`p_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_s_orh` FOREIGN KEY (`s_id`) REFERENCES `shop` (`s_id`) ON DELETE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `fk_p_c` FOREIGN KEY (`c_id`) REFERENCES `customer` (`c_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
