1. Tập tin 521H0461_522H0120.docx là tập tin báo cáo.
2. Thư mục E-Cafe-Management-System-Web-Application-master là mã nguồn.