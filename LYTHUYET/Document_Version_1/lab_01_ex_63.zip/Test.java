public class Test {
    public static void main(String[] args) {
        Rectangle r = new Rectangle(2, 5);
        System.out.println(r.getArea());

        // Shape s = new Rectangle(5, 10); // Right or Wrong?
    }
}