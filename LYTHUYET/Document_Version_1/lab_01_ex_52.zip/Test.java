public class Test {
    public static void main(String[] args) {
        InvoiceItem x = new InvoiceItem("1", "HoaDon1", 1, 1000);
        System.out.println(x.getTotal());
    }
}