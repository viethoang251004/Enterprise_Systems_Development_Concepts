// Lab 1 - Ex. 65

public class Test {

	public static void main(String[] args) {
		
		Shape s = new Circle("red", true, 10);
		System.out.println(s.getArea());

	}

}
