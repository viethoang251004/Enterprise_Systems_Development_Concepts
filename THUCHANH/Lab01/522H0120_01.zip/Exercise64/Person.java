public interface Person {
    String getName();
    void setName(String name);
    String getAddress();
    void setAddress(String address);
    @Override
    String toString();
}
