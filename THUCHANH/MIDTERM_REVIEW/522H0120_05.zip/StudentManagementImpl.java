// DO NOT USE PACKAGE

import java.io.*;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class StudentManagementImpl implements StudentManagement {

    ArrayList<Student> students;

    public StudentManagementImpl() {
        this.students = new ArrayList<>();
    }

    public StudentManagementImpl(String dataPath) {
        this.students = new ArrayList<>();
        readData(dataPath);
    }

    private void readData(String filePath) {
        try {
            File file = new File(filePath);
            BufferedReader br = new BufferedReader(new FileReader(file));

            String readLine = "";
            while ((readLine = br.readLine()) != null) {
                // Insert your code here ...
                String[] parts = readLine.split(","); //assuming the data is comma-separated
                if (parts.length == 5) {
                    String id = parts[0].trim();
                    String name = parts[1].trim();
                    String gender = parts[2].trim();
                    double gpa = Double.parseDouble(parts[3].trim());
                    String major = parts[4].trim();

                    students.add(new Student(id, name, gender, gpa, major));
                }
            }

            br.close();
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public int getNoOfStudent() throws RemoteException {
        // Insert your code here ...
        return students.size();
    }

    @Override
    public int getNoOfStudent_byGender(String gender) throws RemoteException {
        // Insert your code here ...
        return (int) students.stream().filter(s -> s.getGender().equalsIgnoreCase(gender)).count();
    }

    @Override
    public int getNoOfStudent_byMajor(String major) throws RemoteException {
        // Insert your code here ...
        return (int) students.stream().filter(s -> s.getMajor().equalsIgnoreCase(major)).count();
    }

    @Override
    public int getNoOfStudent_byGPA(double gpa) throws RemoteException {
        // Insert your code here ...
        return (int) students.stream().filter(s -> s.getGpa() < gpa).count();
    }

    @Override
    public Student findStudent_byName(String name) throws RemoteException {
        // Insert your code here ...
        // return null;
        return students.stream().filter(s -> s.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    @Override
    public Student findStudent_byID(String id) throws RemoteException {
        // Insert your code here ...
        // return null;
        return students.stream().filter(s -> s.getId().equalsIgnoreCase(id)).findFirst().orElse(null);
    }

    @Override
    public ArrayList<Student> findStudent_byMajor(String major) throws RemoteException {
        // Insert your code here ...
        // return null;
        // ArrayList<Student> result = new ArrayList<>();
        // for (Student s : students) {
        //     if (s.getMajor().equalsIgnoreCase(major)) {
        //         result.add(s);
        //     }
        // }
        // return result;
        return students.stream().filter(s -> s.getMajor().equalsIgnoreCase(major)).collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public ArrayList<Student> findStudent_byGPA(double GPA) throws RemoteException {
        // Insert your code here ...
        // return null;
        // ArrayList<Student> result = new ArrayList<>();
        // for (Student s : students) {
        //     if (s.getGpa() == GPA) {
        //         result.add(s);
        //     }
        // }
        // return result;
        return students.stream().filter(s -> s.getGpa() < GPA).collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public double getAvgGPA() throws RemoteException {
        // Insert your code here ...
        // if (students.isEmpty()) {
        //     return 0.0;
        // }
        // double sum = students.stream().mapToDouble(Student::getGpa).sum();
        // return sum / students.size();
        // return -1;
        if (students.isEmpty()) {
            return 0.0;
        }
        return students.stream().mapToDouble(Student::getGpa).average().orElse(0.0);
    }

    @Override
    public Student getHighestGPA_byGender(String gender) throws RemoteException {
        // Insert your code here ...
        // return null;
        return students.stream().filter(s -> s.getGender().equalsIgnoreCase(gender)).max((s1, s2) -> Double.compare(s1.getGpa(), s2.getGpa())).orElse(null);
    }

    @Override
    public Student getHighestGPA_byFName(String fname) throws RemoteException {
        // return null;
        return students.stream()
                .filter(s -> s.getName().split(" ")[0].equalsIgnoreCase(fname))
                .max((s1, s2) -> Double.compare(s1.getGpa(), s2.getGpa()))
                .orElse(null);
    }

    @Override
    public Student getHighestGPA_byLName(String lname) throws RemoteException {
        // Insert your code here ...
        // return null;
        return students.stream()
                .filter(s -> s.getName().split(" ")[s.getName().split(" ").length - 1].equalsIgnoreCase(lname))
                .max((s1, s2) -> Double.compare(s1.getGpa(), s2.getGpa()))
                .orElse(null);
    }

    @Override
    public Student getHighestGPA_byMajor(String major) throws RemoteException {
        // Insert your code here ...
        // return null;
        return students.stream()
                .filter(s -> s.getMajor().equalsIgnoreCase(major))
                .max((s1, s2) -> Double.compare(s1.getGpa(), s2.getGpa()))
                .orElse(null);
    }

    @Override
    public Student getLowestGPA_byMajor(String major) throws RemoteException {
        // Insert your code here ...
        // return null;
        return students.stream()
                .filter(s -> s.getMajor().equalsIgnoreCase(major))
                .min((s1, s2) -> Double.compare(s1.getGpa(), s2.getGpa()))
                .orElse(null);
    }

    @Override
    public ArrayList<Student> getTop10_byGPA() throws RemoteException {
        // Insert your code here ...
        // return null;
        // return students.stream()
        //         .sorted((s1, s2) -> Double.compare(s2.getGpa(), s1.getGpa()))
        //         .limit(10)
        //         .collect(Collectors.toCollection(ArrayList::new));

        return students.stream().sorted((s1, s2) -> Double.compare(s2.getGpa(), s1.getGpa()))
                .limit(10).collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public ArrayList<Student> getTop10GPA_byGender(String gender) throws RemoteException {
        // Insert your code here ...
        // return null;
        // return students.stream()
        //         .filter(s -> s.getGender().equalsIgnoreCase(gender))
        //         .sorted((s1, s2) -> Double.compare(s2.getGpa(), s1.getGpa()))
        //         .limit(10)
        //         .collect(Collectors.toCollection(ArrayList::new));

        return students.stream().filter(s -> s.getGender().equalsIgnoreCase(gender))
                .sorted((s1, s2) -> Double.compare(s2.getGpa(), s1.getGpa())).limit(10)
                .collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public ArrayList<Student> getTop10GPA_byMajor(String major) throws RemoteException {
        // Insert your code here ...
        // return null;
        // return students.stream()
        //         .filter(s -> s.getMajor().equalsIgnoreCase(major))
        //         .sorted((s1, s2) -> Double.compare(s2.getGpa(), s1.getGpa()))
        //         .limit(10)
        //         .collect(Collectors.toCollection(ArrayList::new));

        return students.stream().filter(s -> s.getMajor().equalsIgnoreCase(major))
                .sorted((s1, s2) -> Double.compare(s2.getGpa(), s1.getGpa())).limit(10)
                .collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public ArrayList<Student> getLast10GPA_byGender(String gender) throws RemoteException {
        // Insert your code here ...
        // return null;
        return students.stream()
                .filter(s -> s.getGender().equalsIgnoreCase(gender))
                .sorted((s1, s2) -> Double.compare(s1.getGpa(), s2.getGpa()))
                .limit(10)
                .collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public ArrayList<Student> getLast10GPA_byMajor(String major) throws RemoteException {
        // Insert your code here ...
        // return null;
        return students.stream()
                .filter(s -> s.getMajor().equalsIgnoreCase(major))
                .sorted((s1, s2) -> Double.compare(s1.getGpa(), s2.getGpa()))
                .limit(10)
                .collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public ArrayList<String> getMajors() throws RemoteException {
        // Insert your code here ...
        // return null;
        // return students.stream()
        //         .map(Student::getMajor)
        //         .distinct()
        //         .collect(Collectors.toCollection(ArrayList::new));

        return students.stream().map(Student::getMajor).distinct()
                .collect(Collectors.toCollection(ArrayList::new));
    }

}
